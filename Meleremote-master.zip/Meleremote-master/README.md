MeleF10Pro_for_Win_XBMC
=======================

An application to use Mele F10 Pro on XBMC in Win7,8,8.1

Mele F10 Pro it's an nice Air Mouse that works pretty good in Android but have no support for Windows so using it in XBMC system on wintel it's pratically impossible.
The remote sends commands that cannot be easily identified because are outside common standards so programs that remap keys will not work.<br>
Here's this application, just start up it when your windows starts (it will appear in application bar) and it will intercep nicely only Mele F10 Pro commands and translate in other commands.<br>

Here's the commands translated:<br>

Keyboard: No changes, will work as usual<br>
Mouse: No changes, act as normal mouse<br>
etc..<br>

The only changes are:<br>
'+' became '+' so it will <b>increase volume</b> on  XBMC<br>
'-' became '-' so it will <b>decrese volume</b> on XBMC<br>
'Light' became c so it will act as <b>information</b> on XBMC<br>
'Speaker' will be bar so it will <b>pause/unpause</b> on XBMC<br>
'The key behind -' (don't know name) will be <b>esc</b><br>
'Telefone up' will be <b>Backspace</b><br>
'Telephone down' will be <b>Tab</b><br>
<< and >> will be as they should be, <b>fast back</b> and <b>fast forward</b>.
'House' will be <b>top</b><br>

So with this app the XBMC will not require any modification or special extension and your system not need any driver modification.<br>The app can left on since it will not interfere and not uses resources.


If you have better ideas about mapping let me know and I make changes and recompile the exes<br>

Note:<br>
There's 2 executables, one for 32 bit systems and one for 64 bit Wint systems, NO Apple support, never, so don't ask!<br>
Checked and works perfect on Win32 bit and Win64 (windows7).

Update 1/6/2014:
I continue receive requests for an Apple version of this app but as I said I will never write this app for Apple, sorry.
I have a couple of Apple stuff but I will never help a company that not support developers and build the most obsolete computers in the history, I know, we can discuss for years about that but this is what I'm think about. I will release the linux version soon but will never work with apple because it relies on frameworks that apple avoid and will never use and of course it will check for apple ones.

Licence: GNU
